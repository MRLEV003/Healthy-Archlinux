//! `hc-rs`: deliberately read-only diagnostics for Arch Linux systems.

use std::env;
use std::fs;
use std::io::Read;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::sync::mpsc;
use std::thread;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

const MEMORY_LIMIT_KIB: u64 = 1024 * 1024;
const TIMEOUT_SECONDS: u64 = 20;
const PACKAGE_CHECK_TIMEOUT_SECONDS: u64 = 15;
const DETAIL_LIMIT: usize = 12_000;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Level {
    Problem,
    Warning,
    Normal,
    Diagnostic,
}

impl Level {
    fn label(self) -> &'static str {
        match self {
            Self::Problem => "PROBLEM",
            Self::Warning => "WARNING",
            Self::Normal => "NORMAL",
            Self::Diagnostic => "DIAGNOSTIC",
        }
    }
}

struct Finding {
    level: Level,
    summary: String,
    detail: String,
}

struct Scanner {
    findings: Vec<Finding>,
    commands: Vec<String>,
    start: Instant,
    stop_requested: bool,
}

impl Scanner {
    fn new() -> Self {
        Self {
            findings: Vec::new(),
            commands: Vec::new(),
            start: Instant::now(),
            stop_requested: false,
        }
    }

    fn add(&mut self, level: Level, summary: impl Into<String>, detail: impl Into<String>) {
        let mut detail = detail.into();
        if detail.len() > DETAIL_LIMIT {
            detail.truncate(DETAIL_LIMIT);
        }
        self.findings.push(Finding {
            level,
            summary: summary.into(),
            detail,
        });
    }

    fn memory_ok(&mut self) -> bool {
        let usage = peak_memory_kib();
        if usage >= MEMORY_LIMIT_KIB {
            self.add(
                Level::Diagnostic,
                "Diagnostic memory limit reached; scan stopped safely.",
                format!("Peak process memory: {usage} KiB; limit: {MEMORY_LIMIT_KIB} KiB."),
            );
            self.stop_requested = true;
            return false;
        }
        true
    }

    /// Runs an explicit command without a shell. Its process group is not changed,
    /// and the command arguments are always fixed by the scanner.
    fn command(&mut self, args: &[&str], timeout_seconds: u64) -> Option<(i32, String)> {
        let rendered = args.join(" ");
        self.commands.push(rendered.clone());
        if !in_path(args[0]) {
            self.add(
                Level::Diagnostic,
                format!("Skipped check: {} is unavailable.", args[0]),
                "",
            );
            return None;
        }
        let mut child = match Command::new(args[0])
            .args(&args[1..])
            .stdin(Stdio::null())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
        {
            Ok(child) => child,
            Err(error) => {
                self.add(
                    Level::Diagnostic,
                    format!("Diagnostic command could not run: {rendered}."),
                    error.to_string(),
                );
                return None;
            }
        };
        let stdout = child.stdout.take();
        let stderr = child.stderr.take();
        let (sender, receiver) = mpsc::channel();
        thread::spawn(move || {
            let mut bytes = Vec::new();
            if let Some(mut pipe) = stdout {
                let _ = pipe.read_to_end(&mut bytes);
            }
            let _ = sender.send(String::from_utf8_lossy(&bytes).into_owned());
        });
        let (error_sender, error_receiver) = mpsc::channel();
        thread::spawn(move || {
            let mut bytes = Vec::new();
            if let Some(mut pipe) = stderr {
                let _ = pipe.read_to_end(&mut bytes);
            }
            let _ = error_sender.send(String::from_utf8_lossy(&bytes).into_owned());
        });
        let deadline = Instant::now() + Duration::from_secs(timeout_seconds);
        loop {
            match child.try_wait() {
                Ok(Some(status)) => {
                    let output = (receiver.recv().unwrap_or_default()
                        + &error_receiver.recv().unwrap_or_default())
                        .trim()
                        .to_owned();
                    return Some((status.code().unwrap_or(-1), output));
                }
                Ok(None) if Instant::now() < deadline => thread::sleep(Duration::from_millis(20)),
                Ok(None) => {
                    let _ = child.kill();
                    let _ = child.wait();
                    let _ = receiver.recv();
                    let _ = error_receiver.recv();
                    self.add(
                        Level::Diagnostic,
                        format!("Diagnostic command timed out: {rendered}."),
                        "",
                    );
                    return None;
                }
                Err(error) => {
                    let _ = child.kill();
                    let _ = child.wait();
                    self.add(
                        Level::Diagnostic,
                        format!("Diagnostic command could not run: {rendered}."),
                        error.to_string(),
                    );
                    return None;
                }
            }
        }
    }

    fn check_arch(&mut self) {
        if !Path::new("/etc/arch-release").exists() && !in_path("pacman") {
            self.add(
                Level::Warning,
                "This host does not appear to be Arch Linux or Arch-based.",
                "",
            );
        } else {
            self.add(Level::Normal, "Arch Linux package tooling detected.", "");
        }
    }

    fn check_systemd(&mut self) {
        if let Some((rc, out)) = self.command(
            &["systemctl", "--failed", "--no-legend", "--plain"],
            TIMEOUT_SECONDS,
        ) {
            if rc == 0 {
                let units: Vec<&str> = out.lines().filter(|line| !line.trim().is_empty()).collect();
                if units.is_empty() {
                    self.add(Level::Normal, "No failed systemd units reported.", "");
                } else {
                    self.add(
                        Level::Problem,
                        format!("{} systemd unit(s) are failed.", units.len()),
                        units.join("\n"),
                    );
                }
            } else {
                self.add(
                    Level::Diagnostic,
                    "Could not query failed systemd units.",
                    out,
                );
            }
        }
    }

    fn check_journal(&mut self) {
        for (label, args) in [
            (
                "current boot",
                vec!["journalctl", "-b", "-p", "err", "--no-pager", "-n", "80"],
            ),
            (
                "previous boot",
                vec![
                    "journalctl",
                    "-b",
                    "-1",
                    "-p",
                    "err",
                    "--no-pager",
                    "-n",
                    "80",
                ],
            ),
        ] {
            if let Some((rc, out)) = self.command(&args, TIMEOUT_SECONDS) {
                if rc == 0 {
                    if !out.is_empty() && !out.contains("-- No entries --") {
                        self.add(
                            Level::Warning,
                            format!("Journal errors found for {label}."),
                            out,
                        );
                    } else {
                        self.add(
                            Level::Normal,
                            format!("No journal errors found for {label}."),
                            "",
                        );
                    }
                } else {
                    self.add(
                        Level::Diagnostic,
                        format!("Could not read {label} error journal."),
                        out,
                    );
                }
            }
        }
    }

    fn check_kernel_and_initramfs(&mut self) {
        if let Some((0, out)) = self.command(&["uname", "-r"], TIMEOUT_SECONDS) {
            self.add(Level::Normal, format!("Running kernel: {out}."), "");
        }
        match self.command(&["pacman", "-Q", "linux"], TIMEOUT_SECONDS) {
            Some((0, out)) => self.add(
                Level::Normal,
                format!("Installed kernel package: {out}."),
                "",
            ),
            Some((1, _)) => {
                let matches = self
                    .command(&["pacman", "-Qq"], TIMEOUT_SECONDS)
                    .map(|(rc, out)| {
                        if rc == 0 {
                            out.lines()
                                .filter(|line| kernel_package(line))
                                .map(str::to_owned)
                                .collect()
                        } else {
                            Vec::new()
                        }
                    })
                    .unwrap_or_default();
                if matches.is_empty() {
                    self.add(Level::Warning, "No standard linux package installed.", "");
                } else {
                    self.add(
                        Level::Normal,
                        format!("Kernel packages: {}.", matches.join(", ")),
                        "",
                    );
                }
            }
            _ => {}
        }
        let roots = [
            PathBuf::from("/boot"),
            PathBuf::from("/efi"),
            PathBuf::from("/boot/efi"),
        ];
        let (classic, ukis, unreadable) = boot_artifacts(&roots);
        if !classic.is_empty() {
            self.add(
                Level::Normal,
                format!(
                    "Found {} classic initramfs image(s) in /boot.",
                    classic.len()
                ),
                "",
            );
        } else if !ukis.is_empty() {
            self.add(
                Level::Normal,
                format!(
                    "Found {} Unified Kernel Image(s) for systemd-boot.",
                    ukis.len()
                ),
                "",
            );
        } else if !unreadable.is_empty() {
            self.add(
                Level::Diagnostic,
                "Boot layout could not be fully checked because UKI files are unreadable.",
                paths(&unreadable),
            );
        } else if !roots.iter().any(|path| path.is_dir()) {
            self.add(
                Level::Diagnostic,
                "Boot layout could not be checked because no boot/EFI mount point is available.",
                "",
            );
        } else {
            self.add(Level::Diagnostic, "Boot layout could not be verified: no classic initramfs or readable UKI was found in known locations.", "");
        }
    }

    fn check_packages(&mut self) {
        if let Some((rc, out)) = self.command(&["pacman", "-Qk"], PACKAGE_CHECK_TIMEOUT_SECONDS) {
            let (confirmed, inaccessible) = package_integrity_output(&out);
            if !confirmed.is_empty() {
                self.add(
                    Level::Problem,
                    "Confirmed installed package file integrity problems.",
                    confirmed.join("\n"),
                );
            } else if !inaccessible.is_empty() {
                self.add(
                    Level::Diagnostic,
                    "Some package files could not be fully checked because permission was denied.",
                    inaccessible.join("\n"),
                );
            } else if rc != 0 {
                self.add(
                    Level::Diagnostic,
                    "Package file integrity check could not be completed.",
                    out,
                );
            } else {
                self.add(
                    Level::Normal,
                    "Installed package file integrity check passed.",
                    "",
                );
            }
        }
        if let Some((rc, out)) = self.command(&["pacman", "-Dk"], TIMEOUT_SECONDS) {
            if rc == 0 {
                self.add(
                    Level::Normal,
                    "Package database dependency check passed.",
                    "",
                );
            } else {
                self.add(
                    Level::Problem,
                    "Package database consistency problems detected.",
                    out,
                );
            }
        }
        match fs::read_to_string("/var/log/pacman.log") {
            Ok(content) => self.add(
                Level::Normal,
                "Recent pacman transactions recorded.",
                content
                    .lines()
                    .rev()
                    .take(40)
                    .collect::<Vec<_>>()
                    .into_iter()
                    .rev()
                    .collect::<Vec<_>>()
                    .join("\n"),
            ),
            Err(error) if Path::new("/var/log/pacman.log").is_file() => self.add(
                Level::Diagnostic,
                "Could not read pacman transaction log.",
                error.to_string(),
            ),
            Err(_) => {}
        }
    }

    fn check_linker(&mut self) {
        if let Some((0, out)) = self.command(
            &[
                "journalctl",
                "-b",
                "-g",
                "ldconfig",
                "--no-pager",
                "-n",
                "80",
            ],
            TIMEOUT_SECONDS,
        ) {
            let crashes: Vec<&str> = out
                .lines()
                .filter(|line| {
                    let lower = line.to_lowercase();
                    lower.contains("segfault")
                        || lower.contains("terminated abnormally")
                        || lower.contains("dumped core")
                })
                .collect();
            if !crashes.is_empty() {
                self.add(
                    Level::Problem,
                    "ldconfig crashed during the current boot.",
                    crashes.join("\n"),
                );
            }
        }
        match fs::metadata("/etc/ld.so.cache") {
            Ok(meta) if meta.len() > 0 => {
                self.add(Level::Normal, "Dynamic linker cache is present.", "")
            }
            _ => self.add(
                Level::Warning,
                "Dynamic linker cache is missing or empty.",
                "",
            ),
        }
        if let Some((rc, out)) = self.command(&["ldconfig", "-p"], TIMEOUT_SECONDS) {
            if rc == 0 {
                self.add(Level::Normal, "Dynamic linker cache is readable.", "");
            } else {
                self.add(
                    Level::Warning,
                    "Dynamic linker cache could not be queried.",
                    out,
                );
            }
        }
    }

    fn check_filesystems(&mut self) {
        if let Some((0, out)) = self.command(
            &["findmnt", "-rn", "-o", "TARGET,SOURCE,FSTYPE,OPTIONS"],
            TIMEOUT_SECONDS,
        ) {
            self.add(
                Level::Normal,
                "Mounted filesystem information collected.",
                out,
            );
        }
        if let Some((0, out)) = self.command(
            &["df", "-P", "-x", "tmpfs", "-x", "devtmpfs"],
            TIMEOUT_SECONDS,
        ) {
            let full: Vec<&str> = out
                .lines()
                .skip(1)
                .filter(|line| usage_at_least(line, 95))
                .collect();
            if full.is_empty() {
                self.add(
                    Level::Normal,
                    "No checked filesystem is at least 95% full.",
                    "",
                );
            } else {
                self.add(
                    Level::Warning,
                    "One or more filesystems are at least 95% full.",
                    full.join("\n"),
                );
            }
        }
        if Path::new("/boot").is_dir() {
            if let Some((0, out)) = self.command(&["df", "-P", "/boot"], TIMEOUT_SECONDS) {
                if out
                    .lines()
                    .last()
                    .is_some_and(|line| usage_at_least(line, 90))
                {
                    self.add(Level::Warning, "/boot is at least 90% full.", out);
                } else {
                    self.add(Level::Normal, "/boot capacity is below 90%.", out);
                }
            }
        }
    }

    fn check_hardware(&mut self) {
        if let Some((0, out)) = self.command(&["lspci", "-nnk"], TIMEOUT_SECONDS) {
            let graphics = out
                .lines()
                .filter(|line| {
                    let lower = line.to_lowercase();
                    ["vga", "3d controller", "display", "kernel driver in use"]
                        .iter()
                        .any(|term| lower.contains(term))
                })
                .collect::<Vec<_>>()
                .join("\n");
            self.add(
                Level::Normal,
                "Graphics hardware information collected.",
                graphics,
            );
        }
        if let Some((0, out)) = self.command(
            &[
                "lsblk",
                "-o",
                "NAME,TYPE,SIZE,FSTYPE,MOUNTPOINTS,ROTA,MODEL",
                "--noheadings",
            ],
            TIMEOUT_SECONDS,
        ) {
            self.add(Level::Normal, "Storage device information collected.", out);
        }
        if let Some((rc, out)) = self.command(&["dmesg", "--level=err,warn"], TIMEOUT_SECONDS) {
            if rc == 0 {
                if out.is_empty() {
                    self.add(
                        Level::Normal,
                        "No kernel warning/error messages available.",
                        "",
                    );
                } else {
                    self.add(
                        Level::Warning,
                        "Kernel warning or error messages found.",
                        tail_chars(&out, DETAIL_LIMIT),
                    );
                }
            } else {
                self.add(
                    Level::Diagnostic,
                    "Kernel log unavailable (often requires additional permission).",
                    out,
                );
            }
        }
    }

    fn run(&mut self) {
        let checks: [fn(&mut Scanner); 8] = [
            Scanner::check_arch,
            Scanner::check_systemd,
            Scanner::check_journal,
            Scanner::check_kernel_and_initramfs,
            Scanner::check_packages,
            Scanner::check_linker,
            Scanner::check_filesystems,
            Scanner::check_hardware,
        ];
        for check in checks {
            if !self.memory_ok() {
                break;
            }
            check(self);
        }
    }

    fn classification(&self) -> &'static str {
        if self
            .findings
            .iter()
            .any(|finding| finding.level == Level::Problem)
        {
            "NEED TO FIX"
        } else if self
            .findings
            .iter()
            .any(|finding| finding.level == Level::Warning || finding.level == Level::Diagnostic)
        {
            "WARNING"
        } else {
            "SAFE"
        }
    }

    fn write_log(
        &self,
        path: &Path,
        started: &str,
        ended: &str,
        duration: Duration,
    ) -> std::io::Result<()> {
        let mut lines = vec![
            "healthy-archlinux diagnostic log".to_owned(),
            format!("Scan start: {started}"),
            format!("Scan end: {ended}"),
            format!(
                "Total execution time: {:.2} seconds",
                duration.as_secs_f64()
            ),
            String::new(),
            "Commands/checks performed:".to_owned(),
        ];
        lines.extend(self.commands.iter().map(|command| format!("- {command}")));
        for level in [
            Level::Problem,
            Level::Warning,
            Level::Normal,
            Level::Diagnostic,
        ] {
            lines.push(String::new());
            lines.push(format!("{} FINDINGS:", level.label()));
            let items: Vec<&Finding> = self
                .findings
                .iter()
                .filter(|finding| finding.level == level)
                .collect();
            if items.is_empty() {
                lines.push("- None".to_owned());
            } else {
                for item in items {
                    lines.push(format!(
                        "- {}{}",
                        item.summary,
                        if item.detail.is_empty() {
                            String::new()
                        } else {
                            format!("\n{}", item.detail)
                        }
                    ));
                }
            }
        }
        lines.push(String::new());
        lines.push(format!("Final classification: {}", self.classification()));
        fs::write(path, lines.join("\n") + "\n")
    }
}

fn in_path(name: &str) -> bool {
    env::var_os("PATH")
        .is_some_and(|paths| env::split_paths(&paths).any(|dir| dir.join(name).is_file()))
}
fn kernel_package(name: &str) -> bool {
    matches!(name, "linux" | "linux-lts" | "linux-zen" | "linux-hardened")
        || (name.starts_with("linux")
            && name[5..]
                .chars()
                .all(|character| character.is_ascii_digit()))
}
fn package_integrity_output(output: &str) -> (Vec<&str>, Vec<&str>) {
    let markers = [
        "(no such file or directory)",
        "(size mismatch)",
        "(sha256 checksum mismatch)",
        "(md5sum mismatch)",
        "(modification time mismatch)",
        "(mode mismatch)",
        "(owner mismatch)",
        "(group mismatch)",
    ];
    let mut confirmed = Vec::new();
    let mut inaccessible = Vec::new();
    for line in output.lines() {
        let lower = line.to_lowercase();
        if lower.contains("permission denied") {
            inaccessible.push(line);
        } else if markers.iter().any(|marker| lower.contains(marker)) {
            confirmed.push(line);
        }
    }
    (confirmed, inaccessible)
}
fn usage_at_least(line: &str, threshold: u32) -> bool {
    line.split_whitespace()
        .nth(4)
        .and_then(|field| field.strip_suffix('%'))
        .and_then(|number| number.parse::<u32>().ok())
        .is_some_and(|percentage| percentage >= threshold)
}
fn tail_chars(input: &str, max: usize) -> String {
    let start = input
        .char_indices()
        .rev()
        .nth(max)
        .map(|(index, _)| index)
        .unwrap_or(0);
    input[start..].to_owned()
}
fn paths(items: &[PathBuf]) -> String {
    items
        .iter()
        .map(|path| path.display().to_string())
        .collect::<Vec<_>>()
        .join("\n")
}

fn boot_artifacts(roots: &[PathBuf]) -> (Vec<PathBuf>, Vec<PathBuf>, Vec<PathBuf>) {
    let mut classic = Vec::new();
    let mut ukis = Vec::new();
    let mut unreadable = Vec::new();
    for root in roots {
        if !root.is_dir() {
            continue;
        }
        if let Ok(entries) = fs::read_dir(root) {
            for entry in entries.flatten() {
                let path = entry.path();
                if path.is_file()
                    && path.file_name().is_some_and(|name| {
                        name.to_string_lossy().starts_with("initramfs-")
                            && name.to_string_lossy().ends_with(".img")
                    })
                {
                    classic.push(path);
                }
            }
        }
        let uki_dir = root.join("EFI/Linux");
        if let Ok(entries) = fs::read_dir(uki_dir) {
            for entry in entries.flatten() {
                let path = entry.path();
                if path.is_file()
                    && path
                        .extension()
                        .is_some_and(|extension| extension.eq_ignore_ascii_case("efi"))
                {
                    match fs::read(&path) {
                        Ok(bytes) if bytes.starts_with(b"MZ") => ukis.push(path),
                        Ok(_) => {}
                        Err(_) => unreadable.push(path),
                    }
                }
            }
        }
    }
    (classic, ukis, unreadable)
}

fn peak_memory_kib() -> u64 {
    fs::read_to_string("/proc/self/status")
        .ok()
        .and_then(|status| {
            status.lines().find_map(|line| {
                line.strip_prefix("VmHWM:")
                    .and_then(|value| value.split_whitespace().next())
                    .and_then(|value| value.parse().ok())
            })
        })
        .unwrap_or(0)
}

fn timestamp() -> String {
    unsafe {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs() as i64;
        let mut output = std::mem::zeroed::<Tm>();
        if localtime_r(&now, &mut output).is_null() {
            return "1970-01-01 00:00:00+0000".to_owned();
        }
        format!(
            "{:04}-{:02}-{:02} {:02}:{:02}:{:02}{:+03}{:02}",
            output.tm_year + 1900,
            output.tm_mon + 1,
            output.tm_mday,
            output.tm_hour,
            output.tm_min,
            output.tm_sec,
            output.tm_gmtoff / 3600,
            (output.tm_gmtoff.abs() % 3600) / 60
        )
    }
}
fn log_filename() -> String {
    unsafe {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs() as i64;
        let mut output = std::mem::zeroed::<Tm>();
        if localtime_r(&now, &mut output).is_null() {
            return "1970-01-01-00-00-00".to_owned();
        }
        format!(
            "{:04}-{:02}-{:02}-{:02}-{:02}-{:02}",
            output.tm_year + 1900,
            output.tm_mon + 1,
            output.tm_mday,
            output.tm_hour,
            output.tm_min,
            output.tm_sec
        )
    }
}

#[repr(C)]
struct Tm {
    tm_sec: i32,
    tm_min: i32,
    tm_hour: i32,
    tm_mday: i32,
    tm_mon: i32,
    tm_year: i32,
    tm_wday: i32,
    tm_yday: i32,
    tm_isdst: i32,
    tm_gmtoff: i64,
    tm_zone: *const i8,
}
unsafe extern "C" {
    fn localtime_r(time: *const i64, result: *mut Tm) -> *mut Tm;
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() {
        println!(
            "No scan started. Run 'hc-rs -s' to start the complete read-only diagnostic scan."
        );
        return;
    }
    if args.len() != 1 || (args[0] != "-s" && args[0] != "--scan") {
        eprintln!("Usage: hc-rs [-s|--scan]");
        std::process::exit(2);
    }
    let started = timestamp();
    let mut scanner = Scanner::new();
    scanner.run();
    let ended = timestamp();
    let duration = scanner.start.elapsed();
    let filename = format!("hclogs-{}.txt", log_filename());
    let home = env::var_os("HOME")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("."));
    let path = home.join(&filename);
    if let Err(error) = scanner.write_log(&path, &started, &ended, duration) {
        eprintln!("Could not write diagnostic log: {error}");
        std::process::exit(2);
    }
    let problems: Vec<&str> = scanner
        .findings
        .iter()
        .filter(|finding| finding.level == Level::Problem)
        .map(|finding| finding.summary.as_str())
        .collect();
    let warnings: Vec<&str> = scanner
        .findings
        .iter()
        .filter(|finding| finding.level == Level::Warning || finding.level == Level::Diagnostic)
        .map(|finding| finding.summary.as_str())
        .collect();
    if !problems.is_empty() {
        println!("\x1b[31m[ NEED TO FIX ]\x1b[0m\n{}", problems.join("\n"));
    } else if !warnings.is_empty() {
        println!("\x1b[33m[ WARNING ]\x1b[0m\n{}", warnings.join("\n"));
    } else {
        println!("\x1b[32m[ SAFE ]\x1b[0m");
    }
    if scanner.stop_requested {
        eprintln!("Error: scan stopped safely because the diagnostic memory limit was reached.");
    }
    println!(
        "Scan completed in {:.2} seconds.\nLog: {filename}\nPath: {}",
        duration.as_secs_f64(),
        path.display()
    );
    if scanner.stop_requested {
        std::process::exit(1);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::time::{SystemTime, UNIX_EPOCH};
    #[test]
    fn timeout_is_diagnostic() {
        let mut scanner = Scanner::new();
        assert!(scanner.command(&["sleep", "1"], 0).is_none());
        assert_eq!(scanner.findings[0].level, Level::Diagnostic);
    }
    #[test]
    fn permission_is_not_problem() {
        let (problems, inaccessible) =
            package_integrity_output("warning: foo: /root/x (Permission denied)");
        assert!(problems.is_empty());
        assert_eq!(inaccessible.len(), 1);
    }
    #[test]
    fn mismatches_are_problems() {
        for text in [
            "warning: foo: x (SHA256 checksum mismatch)",
            "warning: foo: x (Size mismatch)",
        ] {
            assert_eq!(package_integrity_output(text).0.len(), 1);
        }
    }
    #[test]
    fn classic_and_uki_are_detected() {
        let root = env::temp_dir().join(format!(
            "hc-rs-test-{}",
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        fs::create_dir_all(root.join("EFI/Linux")).unwrap();
        fs::write(root.join("initramfs-linux.img"), b"x").unwrap();
        fs::write(root.join("EFI/Linux/arch.efi"), b"MZx").unwrap();
        let (classic, ukis, unreadable) = boot_artifacts(&[root.clone()]);
        assert_eq!(classic.len(), 1);
        assert_eq!(ukis.len(), 1);
        assert!(unreadable.is_empty());
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn kernel_package_names_match_python_logic() {
        assert!(kernel_package("linux-lts"));
        assert!(kernel_package("linux66"));
        assert!(!kernel_package("linux-custom"));
    }
}
